package org.timetodo.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//import org.timetodo.JWT.JwtService;
import org.timetodo.dto.ReminderDto;
import org.timetodo.dto.ReminderRequestDto;
import org.timetodo.entity.ReminderEntity;
import org.timetodo.service.ReminderService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/reminder")
@RequiredArgsConstructor
public class ReminderController {

    private final ReminderService reminderService;
    //private final JwtService jwtService;

    /**
     * 알림 생성 또는 업데이트
     * @param reminderRequestDto 알림 요청 데이터
     * @return 생성된 알림 정보
     */
    @PostMapping("/addTask")
    public ResponseEntity<ReminderDto> createTaskReminder(@RequestBody ReminderRequestDto reminderRequestDto,
                                                          @RequestParam Long taskId) {
        //프론트에서 taskId를 할당해줘야됌 (디코에 코드공유란에 올림) , 할일(taskId)을 선택해서 그 할일에 알림을 설정하는 로직

        //Long taskId = reminderRequestDto.getTaskId();

        log.info("createTaskReminder 메소드의 taskId : {} ", taskId);

        // Reminder 생성
        //reminderService.createTaskReminder(reminderRequestDto, taskId);
        ReminderDto reminder = reminderService.createTaskReminder(reminderRequestDto, taskId);

        //return ResponseEntity.ok("Task Reminder created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(reminder);
    }

    @PostMapping("/addCalendar")
    public ResponseEntity<ReminderDto> createCalendarReminder(@RequestBody ReminderRequestDto reminderRequestDto,
                                                              @RequestParam Long calendarId) {
        //프론트에서 calendarId를 할당해줘야됌 (디코에 코드공유란에 올림)

        //Long calendarId = reminderRequestDto.getCalendarId();

        log.info("createCalendarReminder 메소드의 calendarId: {}", calendarId);

        // Reminder 생성
        //reminderService.createCalendarReminder(reminderRequestDto, calendarId);
        ReminderDto reminder = reminderService.createCalendarReminder(reminderRequestDto, calendarId);

        //return ResponseEntity.ok("Calendar Reminder created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(reminder);

    }

    /**
     * 사용자에 대한 모든 알림 조회
     * @return 알림 목록
     */
    @GetMapping("/findTask")
    public List<ReminderEntity> getTaskReminders(@RequestBody ReminderRequestDto reminderRequestDto) {
        Long taskId = reminderRequestDto.getTaskId();
        return reminderService.getReminderByTaskId(taskId);
    }

    @GetMapping("/findCalendar")
    public List<ReminderEntity> getCalendarsReminders(@RequestBody ReminderRequestDto reminderRequestDto) {
        Long calendarId = reminderRequestDto.getCalendarId();
        return reminderService.getReminderByCalendarId(calendarId);
    }

    /**
     * 알림 삭제
     * @param reminderId 알림 ID
     * @return 성공 응답
     */
    @DeleteMapping("/{reminderId}")
    public ResponseEntity<String> deleteReminder(@PathVariable Long reminderId) {
        reminderService.deleteReminder(reminderId);
        return ResponseEntity.ok("알림 삭제 성공");
    }

}

/*
흐름 요약
addTask 및 addCalendar:

Task 또는 Calendar 생성.
생성된 ID(TaskId 또는 CalendarId)로 JWT 생성.
생성된 JWT를 HTTP 응답 헤더에 포함시켜 클라이언트에 전달.
createTaskReminder 및 createCalendarReminder:

클라이언트에서 Authorization 헤더를 통해 전달된 JWT에서 ID를 추출.
추출된 ID(TaskId 또는 CalendarId)를 기반으로 Reminder 생성.
------------------------------------------------------------
클라이언트 처리
클라이언트는 다음과 같은 흐름으로 작동해야 합니다:

Task/Calendar 생성:

/addTask 또는 /addCalendar를 호출하여 JWT를 응답 헤더에서 저장.
Reminder 생성:

저장된 JWT를 Authorization 헤더에 포함하여 /addTask 또는 /addCalendar를 호출.
 */