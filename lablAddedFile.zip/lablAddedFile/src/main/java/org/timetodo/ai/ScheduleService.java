package org.timetodo.ai;

import org.springframework.stereotype.Service;

@Service
public class ScheduleService {
}
