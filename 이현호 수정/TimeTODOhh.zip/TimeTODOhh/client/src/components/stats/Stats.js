import React from 'react';

function Stats() {
    return (
        <div>
            <h1>통계</h1>
            <p>통계통계</p>
        </div>
    );
}

export default Stats;
