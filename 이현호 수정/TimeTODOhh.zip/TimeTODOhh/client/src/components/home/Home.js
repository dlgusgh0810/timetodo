import React from 'react';

function Home() {
    return (
        <div>
            <h1>홈</h1>
            <p>(홈)</p>
        </div>
    );
}

export default Home;
