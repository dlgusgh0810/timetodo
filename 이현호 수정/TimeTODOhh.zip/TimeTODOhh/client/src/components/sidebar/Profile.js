import {useNavigate} from "react-router-dom";
import Sidebar from "./Sidebar";

const Profile = function(){
    const navigate = useNavigate();
    return (
        <div>
            
        </div>
    )


};

export default Profile;