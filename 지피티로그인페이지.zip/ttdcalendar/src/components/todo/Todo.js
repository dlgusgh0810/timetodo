import React from 'react';

function Todo() {
    return (
        <div>
            <h1>할 일</h1>
            <p>나도 할 일 없었으면 좋겠다</p>
        </div>
    );
}

export default Todo;
